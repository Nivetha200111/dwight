"""
DWIGHT - Dual Pheromone ACO for Disaster Evacuation
====================================================

Based on research papers on earthquake evacuation using ACO:
- Regular pheromone: Attractive, marks good paths to exits
- Deodorant pheromone: Repellent, marks DANGEROUS/BLOCKED paths

When an ant encounters a hazard (fire, collapsed building, etc.):
1. It deposits DEODORANT pheromone to warn others
2. Other ants actively AVOID paths with high deodorant levels
3. The system dynamically reroutes around dangers

This mimics real ant behavior where they deposit repellent pheromones
on branches leading to depleted or dangerous areas.

Controls:
- Click: Add/remove hazard (fire/collapse)
- C: Toggle cache visualization  
- R: Reset simulation
- H: Toggle hazard mode (click to place hazards)
"""

import pygame
import random
import math
from collections import defaultdict

# ----- GRID (20x30) -----
ROWS = 20
COLS = 30

def generate_maze():
    """Generate a new maze."""
    random.seed(42)
    grid = []
    for r in range(ROWS):
        row = []
        for c in range(COLS):
            if r == 0 or r == ROWS - 1 or c == 0 or c == COLS - 1:
                row.append(1)  # Border walls
            elif random.random() < 0.10:
                row.append(1)  # Random internal walls
            else:
                row.append(0)  # Empty
        grid.append(row)
    
    # Ensure start area is clear
    for r in range(1, 5):
        for c in range(1, 5):
            grid[r][c] = 0
    
    # Add exits
    exit_positions = [
        (1, COLS - 2),
        (ROWS - 2, COLS - 2),
        (ROWS // 2, COLS - 2),
        (ROWS - 2, COLS // 2),
    ]
    for er, ec in exit_positions:
        grid[er][ec] = 2
        for dr in range(-1, 2):
            for dc in range(-1, 2):
                nr, nc = er + dr, ec + dc
                if 0 < nr < ROWS - 1 and 0 < nc < COLS - 1 and grid[nr][nc] != 2:
                    grid[nr][nc] = 0
    
    return grid

b = generate_maze()

TILE = 30
WIDTH = COLS * TILE
HEIGHT = ROWS * TILE

# Colors
WALL_DARK = (101, 67, 33)
WALL_LIGHT = (139, 90, 43)
MORTAR = (169, 169, 169)
EMPTY = (220, 220, 220)
DOOR_WOOD = (139, 90, 43)
DOOR_DARK = (101, 67, 33)
DOOR_HANDLE = (255, 215, 0)
BG = (20, 20, 20)
HAZARD_COLOR = (255, 100, 0)  # Orange/red for fire/danger
DEODORANT_COLOR = (255, 50, 50)  # Red tint for repellent areas
CACHED_PATH_COLOR = (255, 200, 0)

STICKMAN_COLORS = [
    (200, 50, 50),
    (50, 50, 200),
    (50, 180, 50),
    (200, 150, 50),
    (150, 50, 200),
    (50, 180, 180),
    (200, 50, 150),
    (100, 100, 100),
]

NUM_ANTS = 8

# ----- DUAL PHEROMONE PARAMETERS -----
ALPHA = 1.0          # Attractive pheromone importance
BETA = 2.0           # Heuristic importance
GAMMA = 5.0          # Success cache importance
DELTA = 3.0          # DEODORANT (repellent) importance - NEW!

RHO_ATTRACT = 0.03   # Evaporation rate for attractive pheromone
RHO_REPEL = 0.01     # Slower evaporation for deodorant (danger persists longer)
Q = 100.0            # Attractive pheromone deposit
Q_REPEL = 200.0      # Deodorant deposit (stronger signal)

# ----- PHEROMONE STORAGE -----
# Attractive pheromone (guides TO exits)
pheromone_attract = {}

# DEODORANT/Repellent pheromone (warns AWAY from dangers)
pheromone_repel = {}

# Hazard cells (user-placed dangers like fire, collapse)
hazards = set()

# Success cache
success_cache = {}
cached_paths = []
MAX_CACHED_PATHS = 5

# Exits
exits = [(r, c) for r in range(ROWS) for c in range(COLS) if b[r][c] == 2]

def get_edge_key(r1, c1, r2, c2):
    if (r1, c1) < (r2, c2):
        return (r1, c1, r2, c2)
    return (r2, c2, r1, c1)

# ----- ATTRACTIVE PHEROMONE -----
def get_attract_pheromone(r1, c1, r2, c2):
    key = get_edge_key(r1, c1, r2, c2)
    return pheromone_attract.get(key, 0.1)

def add_attract_pheromone(r1, c1, r2, c2, amount):
    key = get_edge_key(r1, c1, r2, c2)
    pheromone_attract[key] = pheromone_attract.get(key, 0.1) + amount

# ----- DEODORANT/REPELLENT PHEROMONE -----
def get_repel_pheromone(r1, c1, r2, c2):
    """Get repellent pheromone level on an edge."""
    key = get_edge_key(r1, c1, r2, c2)
    return pheromone_repel.get(key, 0.0)

def add_repel_pheromone(r1, c1, r2, c2, amount):
    """Add deodorant pheromone to mark dangerous path."""
    key = get_edge_key(r1, c1, r2, c2)
    pheromone_repel[key] = pheromone_repel.get(key, 0.0) + amount

def deposit_deodorant_around_hazard(row, col):
    """When hazard is placed, deposit repellent pheromone on all edges leading to it."""
    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nr, nc = row + dr, col + dc
        if 0 <= nr < ROWS and 0 <= nc < COLS:
            add_repel_pheromone(nr, nc, row, col, Q_REPEL * 2)

# ----- SUCCESS CACHE -----
def update_success_cache(path):
    global cached_paths
    if len(path) < 2:
        return
    
    path_length = len(path)
    for i in range(len(path) - 1):
        current = path[i]
        next_cell = path[i + 1]
        remaining_length = path_length - i
        
        if current not in success_cache or success_cache[current][1] > remaining_length:
            success_cache[current] = [next_cell, remaining_length, 1]
        elif success_cache[current][0] == next_cell:
            success_cache[current][2] += 1
    
    cached_paths.append((path_length, path.copy()))
    cached_paths.sort(key=lambda x: x[0])
    cached_paths = cached_paths[:MAX_CACHED_PATHS]

def invalidate_cache_near_hazard(row, col):
    """When a hazard appears, invalidate cached paths that go through or near it."""
    keys_to_remove = []
    for key, (next_cell, _, _) in success_cache.items():
        # If the cached direction leads toward the hazard, remove it
        if next_cell == (row, col) or key == (row, col):
            keys_to_remove.append(key)
        # Also invalidate if adjacent
        kr, kc = key
        if abs(kr - row) <= 1 and abs(kc - col) <= 1:
            keys_to_remove.append(key)
    
    for key in keys_to_remove:
        if key in success_cache:
            del success_cache[key]
    
    # Remove cached paths that go through hazard
    global cached_paths
    cached_paths = [(length, path) for length, path in cached_paths 
                    if (row, col) not in path]

def get_cache_weight(from_row, from_col, to_row, to_col):
    key = (from_row, from_col)
    if key in success_cache:
        cached_next, path_len, times_used = success_cache[key]
        if cached_next == (to_row, to_col):
            confidence = min(times_used / 3.0, 2.0)
            return (1.0 + confidence) * (50.0 / path_len)
    return 0.0

# ----- HELPERS -----
def tile_to_pixels(row, col):
    x = col * TILE + TILE / 2
    y = row * TILE + TILE / 2
    return x, y

def manhattan_to_nearest_exit(row, col):
    if not exits:
        return 1.0
    dmin = min(abs(row - er) + abs(col - ec) for er, ec in exits)
    return 1.0 / (dmin + 1.0)

def get_valid_moves(row, col):
    """Get valid moves, excluding hazards."""
    moves = []
    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nr = row + dr
        nc = col + dc
        if 0 <= nr < ROWS and 0 <= nc < COLS and b[nr][nc] != 1:
            # Don't move directly into hazards
            if (nr, nc) not in hazards:
                moves.append((nr, nc))
    return moves

def choose_next_cell(row, col, exploration_rate=0.1):
    """
    Choose next cell using DUAL PHEROMONE system:
    - Attractive pheromone: INCREASES probability
    - Repellent pheromone: DECREASES probability (deodorant effect)
    """
    neighbors = get_valid_moves(row, col)
    if not neighbors:
        return row, col
    
    # Small chance of exploration
    if random.random() < exploration_rate:
        return random.choice(neighbors)
    
    weights = []
    
    for nr, nc in neighbors:
        # Attractive components
        tau_attract = get_attract_pheromone(row, col, nr, nc)
        eta = manhattan_to_nearest_exit(nr, nc)
        cache_weight = get_cache_weight(row, col, nr, nc)
        
        # REPELLENT component (deodorant pheromone)
        tau_repel = get_repel_pheromone(row, col, nr, nc)
        
        # Base attractive weight
        base_weight = (tau_attract ** ALPHA) * (eta ** BETA)
        
        # Add cache bonus
        if cache_weight > 0:
            base_weight += (cache_weight ** GAMMA)
        
        # SUBTRACT repellent effect (deodorant reduces attractiveness)
        # Use divisor to reduce weight when repellent is high
        repel_factor = 1.0 / (1.0 + tau_repel ** DELTA)
        
        final_weight = base_weight * repel_factor
        
        # Ensure minimum positive weight
        final_weight = max(final_weight, 0.001)
        
        weights.append(final_weight)
    
    total = sum(weights)
    if total <= 0:
        return random.choice(neighbors)
    
    # Roulette wheel selection
    r = random.random() * total
    acc = 0.0
    for (nr, nc), w in zip(neighbors, weights):
        acc += w
        if r <= acc:
            return nr, nc
    
    return neighbors[-1]

def evaporate_pheromones():
    """Evaporate both pheromone types at different rates."""
    # Attractive pheromone evaporates normally
    keys_to_remove = []
    for key in pheromone_attract:
        pheromone_attract[key] *= (1.0 - RHO_ATTRACT)
        if pheromone_attract[key] < 0.01:
            keys_to_remove.append(key)
    for key in keys_to_remove:
        del pheromone_attract[key]
    
    # Deodorant evaporates SLOWER (danger warning persists)
    keys_to_remove = []
    for key in pheromone_repel:
        pheromone_repel[key] *= (1.0 - RHO_REPEL)
        if pheromone_repel[key] < 0.01:
            keys_to_remove.append(key)
    for key in keys_to_remove:
        del pheromone_repel[key]

def deposit_attract_pheromones(path):
    if len(path) < 2:
        return
    L = len(path)
    delta = Q / float(L)
    for i in range(len(path) - 1):
        r1, c1 = path[i]
        r2, c2 = path[i + 1]
        add_attract_pheromone(r1, c1, r2, c2, delta)

def deposit_repel_on_failed_path(path, fail_point):
    """
    When ant encounters hazard, deposit deodorant on the path leading to it.
    This warns other ants to avoid this route.
    """
    if len(path) < 2:
        return
    
    # Deposit repellent on last few edges leading to failure
    lookback = min(5, len(path) - 1)  # Mark last 5 steps
    for i in range(len(path) - lookback - 1, len(path) - 1):
        if i >= 0:
            r1, c1 = path[i]
            r2, c2 = path[i + 1]
            # Stronger repellent closer to hazard
            distance_to_hazard = len(path) - 1 - i
            strength = Q_REPEL / (distance_to_hazard + 1)
            add_repel_pheromone(r1, c1, r2, c2, strength)

# ----- DRAWING FUNCTIONS -----
def draw_brick_wall(surface, x, y, tile_size):
    pygame.draw.rect(surface, MORTAR, (x, y, tile_size, tile_size))
    brick_h = tile_size // 3
    brick_w = tile_size // 2
    gap = 1
    for row in range(3):
        offset = (brick_w // 2) if row % 2 == 1 else 0
        by = y + row * brick_h
        for col in range(-1, 3):
            bx = x + col * brick_w + offset
            color = WALL_DARK if (row + col) % 2 == 0 else WALL_LIGHT
            rect_x = max(bx + gap, x)
            rect_y = by + gap
            rect_w = brick_w - gap * 2
            rect_h = brick_h - gap * 2
            if rect_x < x + tile_size and rect_x + rect_w > x:
                draw_w = min(rect_w, x + tile_size - rect_x)
                if rect_x < x:
                    draw_w -= (x - rect_x)
                    rect_x = x
                pygame.draw.rect(surface, color, (rect_x, rect_y, draw_w, rect_h))

def draw_door(surface, x, y, tile_size):
    pygame.draw.rect(surface, EMPTY, (x, y, tile_size, tile_size))
    door_x = x + 4
    door_y = y + 2
    door_w = tile_size - 8
    door_h = tile_size - 4
    pygame.draw.rect(surface, DOOR_WOOD, (door_x, door_y, door_w, door_h))
    panel_margin = 3
    panel_h = (door_h - 3 * panel_margin) // 2
    panel_w = door_w - 2 * panel_margin
    pygame.draw.rect(surface, DOOR_DARK, 
                     (door_x + panel_margin, door_y + panel_margin, panel_w, panel_h))
    pygame.draw.rect(surface, DOOR_DARK,
                     (door_x + panel_margin, door_y + 2 * panel_margin + panel_h, panel_w, panel_h))
    handle_x = door_x + door_w - 6
    handle_y = door_y + door_h // 2
    pygame.draw.circle(surface, DOOR_HANDLE, (handle_x, handle_y), 2)
    pygame.draw.rect(surface, (60, 40, 20), (door_x, door_y, door_w, door_h), 1)

def draw_hazard(surface, x, y, tile_size):
    """Draw a fire/hazard cell."""
    pygame.draw.rect(surface, (50, 50, 50), (x, y, tile_size, tile_size))
    
    # Animated fire effect
    t = pygame.time.get_ticks() / 100.0
    cx, cy = x + tile_size // 2, y + tile_size // 2
    
    # Draw flames
    for i in range(5):
        offset = math.sin(t + i) * 3
        flame_h = tile_size // 2 + math.sin(t * 2 + i) * 5
        color = (255, 100 + int(math.sin(t + i) * 50), 0)
        points = [
            (cx - 8 + i * 4 + offset, y + tile_size - 2),
            (cx - 4 + i * 4, y + tile_size - flame_h),
            (cx + i * 4 - offset, y + tile_size - 2),
        ]
        pygame.draw.polygon(surface, color, points)
    
    # Warning symbol
    pygame.draw.polygon(surface, (255, 255, 0), [
        (cx, y + 4), (x + 4, y + tile_size - 8), (x + tile_size - 4, y + tile_size - 8)
    ], 2)

def draw_attract_trails(surface):
    """Draw attractive pheromone trails (green)."""
    max_pheromone = 5.0
    for key, level in pheromone_attract.items():
        r1, c1, r2, c2 = key
        intensity = min(level / max_pheromone, 1.0)
        if intensity > 0.05:
            x1, y1 = tile_to_pixels(r1, c1)
            x2, y2 = tile_to_pixels(r2, c2)
            green = int(100 + 155 * intensity)
            width = max(1, int(intensity * 3))
            color = (0, green, 100)
            pygame.draw.line(surface, color, (int(x1), int(y1)), (int(x2), int(y2)), width)

def draw_repel_trails(surface):
    """Draw repellent/deodorant pheromone trails (red)."""
    max_pheromone = 10.0
    for key, level in pheromone_repel.items():
        r1, c1, r2, c2 = key
        intensity = min(level / max_pheromone, 1.0)
        if intensity > 0.05:
            x1, y1 = tile_to_pixels(r1, c1)
            x2, y2 = tile_to_pixels(r2, c2)
            red = int(150 + 105 * intensity)
            width = max(2, int(intensity * 4))
            color = (red, 50, 50)
            pygame.draw.line(surface, color, (int(x1), int(y1)), (int(x2), int(y2)), width)

def draw_cached_paths(surface):
    if not cached_paths:
        return
    for idx, (path_len, path) in enumerate(cached_paths):
        if len(path) < 2:
            continue
        width = 4 if idx == 0 else 2
        color = (255, 200, 0) if idx == 0 else (200, 150, 0)
        for i in range(len(path) - 1):
            r1, c1 = path[i]
            r2, c2 = path[i + 1]
            # Don't draw through hazards
            if (r1, c1) in hazards or (r2, c2) in hazards:
                continue
            x1, y1 = tile_to_pixels(r1, c1)
            x2, y2 = tile_to_pixels(r2, c2)
            pygame.draw.line(surface, color, (int(x1), int(y1)), (int(x2), int(y2)), width)

def draw_stickman(surface, cx, cy, size, direction, color):
    head_r = size // 8
    body_len = size // 4
    leg_len = size // 5
    arm_len = size // 5
    line_width = 2
    
    angle = math.atan2(direction[1], direction[0]) - math.pi / 2
    
    def rotate_point(px, py, angle):
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        return px * cos_a - py * sin_a, px * sin_a + py * cos_a
    
    head_offset = rotate_point(0, -body_len // 2 - head_r, angle)
    head_x = int(cx + head_offset[0])
    head_y = int(cy + head_offset[1])
    
    neck_offset = rotate_point(0, -body_len // 2 + 2, angle)
    neck_x = int(cx + neck_offset[0])
    neck_y = int(cy + neck_offset[1])
    
    hip_offset = rotate_point(0, body_len // 2, angle)
    hip_x = int(cx + hip_offset[0])
    hip_y = int(cy + hip_offset[1])
    
    shoulder_offset = rotate_point(0, -body_len // 4, angle)
    shoulder_x = int(cx + shoulder_offset[0])
    shoulder_y = int(cy + shoulder_offset[1])
    
    walk_phase = pygame.time.get_ticks() / 150.0 + hash(color) % 100
    leg_swing = math.sin(walk_phase) * 0.4
    arm_swing = -math.sin(walk_phase) * 0.3
    
    left_leg_angle = angle + math.pi / 6 + leg_swing
    left_foot = (hip_x + int(leg_len * math.sin(left_leg_angle)),
                 hip_y + int(leg_len * math.cos(left_leg_angle)))
    
    right_leg_angle = angle - math.pi / 6 - leg_swing
    right_foot = (hip_x + int(leg_len * math.sin(right_leg_angle)),
                  hip_y + int(leg_len * math.cos(right_leg_angle)))
    
    left_arm_angle = angle + math.pi / 4 + arm_swing
    left_hand = (shoulder_x + int(arm_len * math.sin(left_arm_angle)),
                 shoulder_y + int(arm_len * math.cos(left_arm_angle)))
    
    right_arm_angle = angle - math.pi / 4 - arm_swing
    right_hand = (shoulder_x + int(arm_len * math.sin(right_arm_angle)),
                  shoulder_y + int(arm_len * math.cos(right_arm_angle)))
    
    pygame.draw.circle(surface, color, (head_x, head_y), head_r, line_width)
    pygame.draw.line(surface, color, (neck_x, neck_y), (hip_x, hip_y), line_width)
    pygame.draw.line(surface, color, (hip_x, hip_y), left_foot, line_width)
    pygame.draw.line(surface, color, (hip_x, hip_y), right_foot, line_width)
    pygame.draw.line(surface, color, (shoulder_x, shoulder_y), left_hand, line_width)
    pygame.draw.line(surface, color, (shoulder_x, shoulder_y), right_hand, line_width)

# ----- ANT CLASS -----
class Ant:
    def __init__(self, ant_id, color):
        self.id = ant_id
        self.color = color
        self.start_row = 1 + ant_id % 3
        self.start_col = 1 + ant_id // 3
        self.row = self.start_row
        self.col = self.start_col
        self.x, self.y = tile_to_pixels(self.row, self.col)
        self.target_x = self.x
        self.target_y = self.y
        self.moving = False
        self.direction = (0, 1)
        self.path = [(self.row, self.col)]
        self.trips = 0
        self.best_path = float('inf')
        self.exploration_rate = 0.15
        self.stuck_counter = 0
    
    def reset_to_start(self):
        self.row = self.start_row
        self.col = self.start_col
        self.x, self.y = tile_to_pixels(self.row, self.col)
        self.target_x = self.x
        self.target_y = self.y
        self.path = [(self.row, self.col)]
        self.moving = False
        self.stuck_counter = 0
    
    def update(self, dt):
        if not self.moving:
            # Check if current position became hazardous
            if (self.row, self.col) in hazards:
                # Deposit deodorant on path leading here
                deposit_repel_on_failed_path(self.path, (self.row, self.col))
                self.reset_to_start()
                return
            
            if b[self.row][self.col] == 2:
                # SUCCESS - reached exit!
                path_len = len(self.path)
                if path_len < self.best_path:
                    self.best_path = path_len
                self.trips += 1
                
                deposit_attract_pheromones(self.path)
                update_success_cache(self.path)
                self.exploration_rate = max(0.02, self.exploration_rate * 0.9)
                self.reset_to_start()
            else:
                nr, nc = choose_next_cell(self.row, self.col, self.exploration_rate)
                
                if (nr, nc) == (self.row, self.col):
                    # Stuck - no valid moves
                    self.stuck_counter += 1
                    if self.stuck_counter > 10:
                        # Deposit deodorant and reset
                        deposit_repel_on_failed_path(self.path, (self.row, self.col))
                        self.reset_to_start()
                else:
                    self.stuck_counter = 0
                    self.direction = (nc - self.col, nr - self.row)
                    self.target_x, self.target_y = tile_to_pixels(nr, nc)
                    self.path.append((nr, nc))
                    self.row, self.col = nr, nc
                    self.moving = True
        
        if self.moving:
            dx = self.target_x - self.x
            dy = self.target_y - self.y
            dist = math.hypot(dx, dy)
            
            if dist < 1:
                self.x, self.y = self.target_x, self.target_y
                self.moving = False
            else:
                speed = 180.0
                nx = dx / dist
                ny = dy / dist
                step = speed * dt
                if step >= dist:
                    self.x, self.y = self.target_x, self.target_y
                    self.moving = False
                else:
                    self.x += nx * step
                    self.y += ny * step
    
    def draw(self, surface):
        draw_stickman(surface, int(self.x), int(self.y), TILE, self.direction, self.color)

# Create ants
ants = [Ant(i, STICKMAN_COLORS[i % len(STICKMAN_COLORS)]) for i in range(NUM_ANTS)]

# ----- Pygame Setup -----
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT + 90))
pygame.display.set_caption("DWIGHT — Dual Pheromone Disaster Evacuation")
font = pygame.font.Font(None, 22)
font_small = pygame.font.Font(None, 18)

clock = pygame.time.Clock()
running = True
frame_count = 0
show_cache = True
hazard_mode = True  # Start in hazard mode

while running:
    dt = clock.tick(60) / 1000.0
    frame_count += 1

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_c:
                show_cache = not show_cache
            elif event.key == pygame.K_h:
                hazard_mode = not hazard_mode
            elif event.key == pygame.K_r:
                # Reset
                pheromone_attract.clear()
                pheromone_repel.clear()
                success_cache.clear()
                cached_paths.clear()
                hazards.clear()
                for ant in ants:
                    ant.reset_to_start()
                    ant.trips = 0
                    ant.best_path = float('inf')
                    ant.exploration_rate = 0.15
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if hazard_mode:
                mx, my = event.pos
                if my < HEIGHT:  # Only in grid area
                    col = mx // TILE
                    row = my // TILE
                    if 0 < row < ROWS - 1 and 0 < col < COLS - 1:
                        if b[row][col] == 0:  # Only on empty cells
                            if (row, col) in hazards:
                                # Remove hazard
                                hazards.remove((row, col))
                            else:
                                # Add hazard
                                hazards.add((row, col))
                                # Deposit deodorant around new hazard
                                deposit_deodorant_around_hazard(row, col)
                                # Invalidate cached paths through hazard
                                invalidate_cache_near_hazard(row, col)

    # Evaporate pheromones
    if frame_count % 5 == 0:
        evaporate_pheromones()

    # Update ants
    for ant in ants:
        ant.update(dt)

    # ----- DRAW -----
    screen.fill(BG)

    # Draw grid
    for row in range(ROWS):
        for col in range(COLS):
            x = col * TILE
            y = row * TILE

            if (row, col) in hazards:
                draw_hazard(screen, x, y, TILE)
            elif b[row][col] == 1:
                draw_brick_wall(screen, x, y, TILE)
            elif b[row][col] == 0:
                pygame.draw.rect(screen, EMPTY, (x, y, TILE, TILE))
            elif b[row][col] == 2:
                draw_door(screen, x, y, TILE)

    # Draw pheromone trails
    draw_attract_trails(screen)  # Green - attractive
    draw_repel_trails(screen)    # Red - deodorant/repellent
    
    if show_cache:
        draw_cached_paths(screen)

    # Draw ants
    for ant in ants:
        ant.draw(screen)

    # ----- STATS -----
    stats_y = HEIGHT + 5
    total_trips = sum(ant.trips for ant in ants)
    best_overall = min((ant.best_path for ant in ants if ant.best_path != float('inf')), default=float('inf'))
    
    trips_text = font.render(f"Trips: {total_trips}", True, (200, 200, 200))
    best_text = font.render(f"Best: {best_overall if best_overall != float('inf') else '-'}", True, (200, 200, 200))
    hazards_text = font.render(f"Hazards: {len(hazards)}", True, HAZARD_COLOR)
    
    screen.blit(trips_text, (10, stats_y))
    screen.blit(best_text, (100, stats_y))
    screen.blit(hazards_text, (200, stats_y))
    
    # Pheromone counts
    attract_text = font.render(f"Attract: {len(pheromone_attract)}", True, (0, 200, 100))
    repel_text = font.render(f"Repel: {len(pheromone_repel)}", True, (255, 100, 100))
    screen.blit(attract_text, (320, stats_y))
    screen.blit(repel_text, (450, stats_y))
    
    # Ant stats
    stats_y2 = HEIGHT + 28
    for i, ant in enumerate(ants):
        color_rect = pygame.Rect(10 + i * 110, stats_y2, 12, 12)
        pygame.draw.rect(screen, ant.color, color_rect)
        ant_stat = font.render(f": {ant.trips}", True, (180, 180, 180))
        screen.blit(ant_stat, (25 + i * 110, stats_y2))

    # Instructions
    stats_y3 = HEIGHT + 50
    mode_color = HAZARD_COLOR if hazard_mode else (100, 100, 100)
    mode_text = "CLICK TO ADD HAZARDS" if hazard_mode else "Hazard mode OFF"
    
    inst1 = font_small.render(f"H: Toggle hazard mode [{mode_text}] | C: Toggle cache | R: Reset", True, mode_color)
    screen.blit(inst1, (10, stats_y3))
    
    stats_y4 = HEIGHT + 68
    inst2 = font_small.render("GREEN = attractive pheromone (good paths) | RED = deodorant pheromone (danger warning)", True, (120, 120, 120))
    screen.blit(inst2, (10, stats_y4))

    pygame.display.flip()

pygame.quit()
