"""
DWIGHT - Minecraft Map Style ACO
================================
Clean top-down view like Minecraft's map/F3 view
Ready to be ported to actual Minecraft!

Controls:
- Click: Add/remove fire hazard  
- R: Reset simulation
- +/-: Speed up/slow down
- Space: Pause/resume
"""

import pygame
import random
import math

pygame.init()

# ----- GRID -----
ROWS = 20
COLS = 30
TILE = 32

WIDTH = COLS * TILE
HEIGHT = ROWS * TILE + 80  # Extra for UI

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DWIGHT - Minecraft Map View")

# ----- MINECRAFT-STYLE COLORS -----
GRASS_TOP = (89, 176, 60)
STONE = (125, 125, 125)
BRICK = (150, 90, 75)
OAK_PLANKS = (162, 130, 78)
GOLD_BLOCK = (249, 236, 79)
FIRE = (252, 163, 17)
NETHERRACK = (97, 38, 39)
BEDROCK = (52, 52, 52)
GLOWSTONE = (171, 131, 45)

# Pheromone colors
SLIME_GREEN = (51, 204, 51)  # Attractive
REDSTONE = (255, 0, 0)       # Repellent

# ----- ACO PARAMETERS -----
ALPHA = 1.0
BETA = 2.0
GAMMA = 5.0
DELTA = 3.0
RHO_ATTRACT = 0.03
RHO_REPEL = 0.01
Q = 100.0
Q_REPEL = 200.0

pheromone_attract = {}
pheromone_repel = {}
success_cache = {}
hazards = set()

# ----- GENERATE MAZE -----
random.seed(42)
maze = []
exits = []

for r in range(ROWS):
    row = []
    for c in range(COLS):
        if r == 0 or r == ROWS - 1 or c == 0 or c == COLS - 1:
            row.append(1)  # Bedrock border
        elif random.random() < 0.10:
            row.append(1)  # Stone walls
        else:
            row.append(0)  # Grass floor
    maze.append(row)

# Clear spawn area
for r in range(1, 5):
    for c in range(1, 5):
        maze[r][c] = 0

# Add exits (gold blocks = safe zone)
exit_positions = [(1, COLS-2), (ROWS-2, COLS-2), (ROWS//2, COLS-2), (ROWS-2, COLS//2)]
for er, ec in exit_positions:
    maze[er][ec] = 2
    exits.append((er, ec))
    for dr in range(-1, 2):
        for dc in range(-1, 2):
            nr, nc = er + dr, ec + dc
            if 0 < nr < ROWS-1 and 0 < nc < COLS-1 and maze[nr][nc] != 2:
                maze[nr][nc] = 0

# ----- PHEROMONE FUNCTIONS -----
def get_edge_key(r1, c1, r2, c2):
    return (min(r1,r2), min(c1,c2), max(r1,r2), max(c1,c2))

def get_attract(r1, c1, r2, c2):
    return pheromone_attract.get(get_edge_key(r1,c1,r2,c2), 0.1)

def add_attract(r1, c1, r2, c2, amt):
    key = get_edge_key(r1,c1,r2,c2)
    pheromone_attract[key] = pheromone_attract.get(key, 0.1) + amt

def get_repel(r1, c1, r2, c2):
    return pheromone_repel.get(get_edge_key(r1,c1,r2,c2), 0.0)

def add_repel(r1, c1, r2, c2, amt):
    key = get_edge_key(r1,c1,r2,c2)
    pheromone_repel[key] = pheromone_repel.get(key, 0.0) + amt

def deposit_deodorant(row, col):
    for dr, dc in [(-1,0), (1,0), (0,-1), (0,1)]:
        nr, nc = row+dr, col+dc
        if 0 <= nr < ROWS and 0 <= nc < COLS:
            add_repel(nr, nc, row, col, Q_REPEL * 2)

def evaporate():
    for key in list(pheromone_attract.keys()):
        pheromone_attract[key] *= (1 - RHO_ATTRACT)
        if pheromone_attract[key] < 0.01:
            del pheromone_attract[key]
    for key in list(pheromone_repel.keys()):
        pheromone_repel[key] *= (1 - RHO_REPEL)
        if pheromone_repel[key] < 0.01:
            del pheromone_repel[key]

def nearest_exit_dist(row, col):
    if not exits:
        return 1.0
    return 1.0 / (min(abs(row-er) + abs(col-ec) for er,ec in exits) + 1)

def get_moves(row, col):
    moves = []
    for dr, dc in [(-1,0), (1,0), (0,-1), (0,1)]:
        nr, nc = row+dr, col+dc
        if 0 <= nr < ROWS and 0 <= nc < COLS and maze[nr][nc] != 1 and (nr,nc) not in hazards:
            moves.append((nr, nc))
    return moves

def get_cache_weight(fr, fc, tr, tc):
    if (fr, fc) in success_cache:
        cached, plen, used = success_cache[(fr, fc)]
        if cached == (tr, tc):
            return (1 + min(used/3, 2)) * (50/plen)
    return 0

def choose_next(row, col, explore=0.1):
    neighbors = get_moves(row, col)
    if not neighbors:
        return row, col
    if random.random() < explore:
        return random.choice(neighbors)
    
    weights = []
    for nr, nc in neighbors:
        tau = get_attract(row, col, nr, nc)
        eta = nearest_exit_dist(nr, nc)
        cache = get_cache_weight(row, col, nr, nc)
        repel = get_repel(row, col, nr, nc)
        
        w = (tau ** ALPHA) * (eta ** BETA)
        if cache > 0:
            w += cache ** GAMMA
        w *= 1 / (1 + repel ** DELTA)
        weights.append(max(w, 0.001))
    
    total = sum(weights)
    r = random.random() * total
    acc = 0
    for (nr, nc), w in zip(neighbors, weights):
        acc += w
        if r <= acc:
            return nr, nc
    return neighbors[-1]

def update_cache(path):
    if len(path) < 2:
        return
    for i in range(len(path) - 1):
        cur, nxt = path[i], path[i+1]
        rem = len(path) - i
        if cur not in success_cache or success_cache[cur][1] > rem:
            success_cache[cur] = [nxt, rem, 1]
        elif success_cache[cur][0] == nxt:
            success_cache[cur][2] += 1

def deposit_attract(path):
    if len(path) < 2:
        return
    delta = Q / len(path)
    for i in range(len(path) - 1):
        add_attract(path[i][0], path[i][1], path[i+1][0], path[i+1][1], delta)

def deposit_repel_path(path):
    if len(path) < 2:
        return
    for i in range(max(0, len(path)-6), len(path)-1):
        strength = Q_REPEL / (len(path) - i)
        add_repel(path[i][0], path[i][1], path[i+1][0], path[i+1][1], strength)

# ----- DRAWING FUNCTIONS -----
def draw_block(surface, row, col, base_color, border=True):
    """Draw a Minecraft-style block."""
    x, y = col * TILE, row * TILE
    
    # Main block
    pygame.draw.rect(surface, base_color, (x, y, TILE, TILE))
    
    if border:
        # Darker edges for 3D effect
        dark = tuple(max(0, c - 40) for c in base_color)
        light = tuple(min(255, c + 30) for c in base_color)
        
        # Top highlight
        pygame.draw.line(surface, light, (x, y), (x + TILE - 1, y), 2)
        pygame.draw.line(surface, light, (x, y), (x, y + TILE - 1), 2)
        
        # Bottom shadow
        pygame.draw.line(surface, dark, (x, y + TILE - 1), (x + TILE - 1, y + TILE - 1), 2)
        pygame.draw.line(surface, dark, (x + TILE - 1, y), (x + TILE - 1, y + TILE - 1), 2)

def draw_fire(surface, row, col, time_val):
    """Draw animated fire block."""
    x, y = col * TILE, row * TILE
    
    # Netherrack base
    pygame.draw.rect(surface, NETHERRACK, (x, y, TILE, TILE))
    
    # Animated flames
    for i in range(4):
        fx = x + 4 + i * 7
        flame_h = 12 + math.sin(time_val * 10 + i * 2 + col) * 6
        fy = y + TILE - 4 - flame_h
        
        # Flame colors
        colors = [(255, 200, 50), (255, 150, 0), (255, 100, 0)]
        c = colors[i % 3]
        
        # Draw flame shape
        points = [
            (fx, y + TILE - 4),
            (fx - 3, y + TILE - 4),
            (fx, fy),
            (fx + 3, y + TILE - 4),
        ]
        pygame.draw.polygon(surface, c, points)

def draw_steve(surface, x, y, color, direction, time_val, ant_id):
    """Draw a mini Steve character."""
    bob = math.sin(time_val * 10 + ant_id) * 2
    cy = y + bob
    
    # Shadow
    pygame.draw.ellipse(surface, (50, 50, 50), (x - 6, y + 10, 12, 6))
    
    # Body
    pygame.draw.rect(surface, color, (x - 4, cy - 6, 8, 10))
    
    # Head (skin color)
    pygame.draw.rect(surface, (200, 160, 120), (x - 5, cy - 14, 10, 9))
    
    # Hair
    pygame.draw.rect(surface, (60, 40, 20), (x - 5, cy - 14, 10, 3))
    
    # Eyes
    pygame.draw.rect(surface, (255, 255, 255), (x - 3, cy - 11, 2, 2))
    pygame.draw.rect(surface, (255, 255, 255), (x + 1, cy - 11, 2, 2))
    pygame.draw.rect(surface, (0, 0, 0), (x - 2, cy - 10, 1, 1))
    pygame.draw.rect(surface, (0, 0, 0), (x + 2, cy - 10, 1, 1))
    
    # Legs (animated)
    leg_swing = math.sin(time_val * 12 + ant_id) * 3
    pygame.draw.rect(surface, (50, 50, 150), (x - 4, cy + 4 + leg_swing, 3, 6))
    pygame.draw.rect(surface, (50, 50, 150), (x + 1, cy + 4 - leg_swing, 3, 6))

# ----- ANT CLASS -----
SHIRT_COLORS = [
    (200, 50, 50),   # Red
    (50, 50, 200),   # Blue  
    (50, 180, 50),   # Green
    (200, 150, 50),  # Orange
    (150, 50, 200),  # Purple
    (50, 180, 180),  # Cyan
    (200, 50, 150),  # Pink
    (100, 100, 100), # Gray
]

class Ant:
    def __init__(self, ant_id):
        self.id = ant_id
        self.color = SHIRT_COLORS[ant_id % len(SHIRT_COLORS)]
        self.start_row = 1 + ant_id % 3
        self.start_col = 1 + ant_id // 3
        self.reset()
        self.trips = 0
        self.explore = 0.15
    
    def reset(self):
        self.row = self.start_row
        self.col = self.start_col
        self.x = self.col * TILE + TILE // 2
        self.y = self.row * TILE + TILE // 2
        self.tx = self.x
        self.ty = self.y
        self.path = [(self.row, self.col)]
        self.moving = False
        self.stuck = 0
        self.direction = (0, 1)
    
    def update(self, dt):
        if not self.moving:
            if (self.row, self.col) in hazards:
                deposit_repel_path(self.path)
                self.reset()
                return
            
            if maze[self.row][self.col] == 2:
                self.trips += 1
                deposit_attract(self.path)
                update_cache(self.path)
                self.explore = max(0.02, self.explore * 0.9)
                self.reset()
            else:
                nr, nc = choose_next(self.row, self.col, self.explore)
                if (nr, nc) == (self.row, self.col):
                    self.stuck += 1
                    if self.stuck > 10:
                        deposit_repel_path(self.path)
                        self.reset()
                else:
                    self.stuck = 0
                    self.direction = (nc - self.col, nr - self.row)
                    self.tx = nc * TILE + TILE // 2
                    self.ty = nr * TILE + TILE // 2
                    self.path.append((nr, nc))
                    self.row, self.col = nr, nc
                    self.moving = True
        
        if self.moving:
            speed = 150
            dx, dy = self.tx - self.x, self.ty - self.y
            dist = math.hypot(dx, dy)
            if dist < 2:
                self.x, self.y = self.tx, self.ty
                self.moving = False
            else:
                self.x += (dx / dist) * speed * dt
                self.y += (dy / dist) * speed * dt
    
    def draw(self, surface, time_val):
        draw_steve(surface, self.x, self.y, self.color, self.direction, time_val, self.id)

# Create ants
ants = [Ant(i) for i in range(8)]

# ----- MAIN LOOP -----
clock = pygame.time.Clock()
running = True
paused = False
speed = 1.0
frame = 0
font = pygame.font.Font(None, 24)
font_big = pygame.font.Font(None, 32)

while running:
    dt = clock.tick(60) / 1000.0 * speed
    frame += 1
    time_val = pygame.time.get_ticks() / 1000.0
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = event.pos
            if my < ROWS * TILE:
                col, row = mx // TILE, my // TILE
                if 0 < row < ROWS-1 and 0 < col < COLS-1 and maze[row][col] == 0:
                    if (row, col) in hazards:
                        hazards.remove((row, col))
                    else:
                        hazards.add((row, col))
                        deposit_deodorant(row, col)
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r:
                pheromone_attract.clear()
                pheromone_repel.clear()
                success_cache.clear()
                hazards.clear()
                for ant in ants:
                    ant.reset()
                    ant.trips = 0
                    ant.explore = 0.15
            elif event.key == pygame.K_SPACE:
                paused = not paused
            elif event.key == pygame.K_EQUALS or event.key == pygame.K_PLUS:
                speed = min(speed + 0.5, 5.0)
            elif event.key == pygame.K_MINUS:
                speed = max(speed - 0.5, 0.5)
    
    if not paused:
        if frame % 8 == 0:
            evaporate()
        for ant in ants:
            ant.update(dt)
    
    # ----- DRAW -----
    screen.fill(BEDROCK)
    
    # Draw grid
    for row in range(ROWS):
        for col in range(COLS):
            cell = maze[row][col]
            
            if (row, col) in hazards:
                draw_fire(screen, row, col, time_val)
            elif cell == 1:
                draw_block(screen, row, col, STONE if row == 0 or row == ROWS-1 or col == 0 or col == COLS-1 else BRICK)
            elif cell == 2:
                draw_block(screen, row, col, GOLD_BLOCK)
                # Door overlay
                x, y = col * TILE, row * TILE
                pygame.draw.rect(screen, OAK_PLANKS, (x + 6, y + 2, TILE - 12, TILE - 4))
                pygame.draw.rect(screen, (80, 60, 40), (x + 6, y + 2, TILE - 12, TILE - 4), 2)
                pygame.draw.circle(screen, GLOWSTONE, (x + TILE - 10, y + TILE // 2), 3)
            else:
                draw_block(screen, row, col, GRASS_TOP)
    
    # Draw pheromone trails
    for key, level in pheromone_attract.items():
        intensity = min(level / 5.0, 1.0)
        if intensity > 0.1:
            r1, c1, r2, c2 = key
            x1 = (c1 + 0.5) * TILE
            y1 = (r1 + 0.5) * TILE
            x2 = (c2 + 0.5) * TILE
            y2 = (r2 + 0.5) * TILE
            
            green = int(100 + 155 * intensity)
            width = max(2, int(intensity * 5))
            pygame.draw.line(screen, (0, green, 50), (x1, y1), (x2, y2), width)
            
            # Glowing particle
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            glow_size = int(3 + intensity * 4 + math.sin(time_val * 5) * 2)
            pygame.draw.circle(screen, SLIME_GREEN, (int(mx), int(my)), glow_size)
    
    for key, level in pheromone_repel.items():
        intensity = min(level / 10.0, 1.0)
        if intensity > 0.1:
            r1, c1, r2, c2 = key
            x1 = (c1 + 0.5) * TILE
            y1 = (r1 + 0.5) * TILE
            x2 = (c2 + 0.5) * TILE
            y2 = (r2 + 0.5) * TILE
            
            red = int(100 + 155 * intensity)
            width = max(2, int(intensity * 6))
            pygame.draw.line(screen, (red, 30, 30), (x1, y1), (x2, y2), width)
            
            # Redstone particle
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            glow_size = int(4 + intensity * 5 + math.sin(time_val * 7) * 2)
            pygame.draw.circle(screen, REDSTONE, (int(mx), int(my)), glow_size)
    
    # Draw ants
    sorted_ants = sorted(ants, key=lambda a: a.row)
    for ant in sorted_ants:
        ant.draw(screen, time_val)
    
    # ----- UI -----
    ui_y = ROWS * TILE + 5
    
    # Stats bar
    pygame.draw.rect(screen, (30, 30, 30), (0, ROWS * TILE, WIDTH, 80))
    
    total_trips = sum(a.trips for a in ants)
    
    # Title
    title = font_big.render("DWIGHT - Disaster Evacuation ACO", True, (255, 255, 255))
    screen.blit(title, (10, ui_y))
    
    # Stats
    stats = f"Trips: {total_trips}  |  Fires: {len(hazards)}  |  Speed: {speed:.1f}x"
    if paused:
        stats += "  [PAUSED]"
    stats_surf = font.render(stats, True, (200, 200, 200))
    screen.blit(stats_surf, (10, ui_y + 28))
    
    # Legend
    pygame.draw.circle(screen, SLIME_GREEN, (10, ui_y + 55), 6)
    screen.blit(font.render("Safe Path", True, (150, 255, 150)), (22, ui_y + 48))
    
    pygame.draw.circle(screen, REDSTONE, (120, ui_y + 55), 6)
    screen.blit(font.render("Danger!", True, (255, 150, 150)), (132, ui_y + 48))
    
    # Controls
    controls = "Click: Fire | R: Reset | Space: Pause | +/-: Speed"
    screen.blit(font.render(controls, True, (150, 150, 150)), (WIDTH - 350, ui_y + 55))
    
    pygame.display.flip()

pygame.quit()
