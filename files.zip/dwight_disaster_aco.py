import pygame
import random
import math
from collections import defaultdict

# ----- GRID (20x30) -----
b = []
ROWS = 20
COLS = 30

# Generate maze with walls around edges and some internal walls
random.seed(42)  # Fixed seed for reproducible maze
for r in range(ROWS):
    row = []
    for c in range(COLS):
        if r == 0 or r == ROWS - 1 or c == 0 or c == COLS - 1:
            row.append(1)  # Border walls
        elif random.random() < 0.12:
            row.append(1)  # Random internal walls
        else:
            row.append(0)  # Empty
    b.append(row)

# Ensure start area is clear
for r in range(1, 5):
    for c in range(1, 5):
        b[r][c] = 0

# Add multiple exits (emergency exits)
exit_positions = [
    (1, COLS - 2),
    (ROWS - 2, COLS - 2),
    (ROWS // 2, COLS - 2),
    (ROWS - 2, COLS // 2),
]
for er, ec in exit_positions:
    b[er][ec] = 2
    # Clear area around exits
    for dr in range(-1, 2):
        for dc in range(-1, 2):
            nr, nc = er + dr, ec + dc
            if 0 < nr < ROWS - 1 and 0 < nc < COLS - 1 and b[nr][nc] != 2:
                b[nr][nc] = 0

TILE = 30
WIDTH = COLS * TILE
HEIGHT = ROWS * TILE

# Colors
WALL_DARK = (101, 67, 33)
WALL_LIGHT = (139, 90, 43)
MORTAR = (169, 169, 169)
EMPTY = (220, 220, 220)
DOOR_WOOD = (139, 90, 43)
DOOR_DARK = (101, 67, 33)
DOOR_HANDLE = (255, 215, 0)
BG = (20, 20, 20)
CACHED_PATH_COLOR = (255, 200, 0)  # Gold for cached successful paths

# Stickman colors
STICKMAN_COLORS = [
    (200, 50, 50),    # Red
    (50, 50, 200),    # Blue
    (50, 180, 50),    # Green
    (200, 150, 50),   # Orange
    (150, 50, 200),   # Purple
    (50, 180, 180),   # Cyan
    (200, 50, 150),   # Pink
    (100, 100, 100),  # Gray
]

NUM_ANTS = 8

# ----- ACO PARAMETERS -----
ALPHA = 1.0          # Pheromone importance
BETA = 2.0           # Heuristic importance
GAMMA = 5.0          # SUCCESS CACHE importance (NEW!)
RHO = 0.03           # Evaporation rate
Q = 100.0            # Pheromone deposit amount

# Pheromone on edges
pheromone_edges = {}

# ----- SUCCESS CACHE (NEW!) -----
# Stores the best known path from each cell to nearest exit
# Format: success_cache[(row, col)] = [(next_row, next_col), path_length, times_used]
success_cache = {}

# Store complete successful paths for visualization
cached_paths = []  # List of paths that led to exits
MAX_CACHED_PATHS = 5  # Keep top N best paths

def get_edge_key(r1, c1, r2, c2):
    if (r1, c1) < (r2, c2):
        return (r1, c1, r2, c2)
    return (r2, c2, r1, c1)

def get_pheromone(r1, c1, r2, c2):
    key = get_edge_key(r1, c1, r2, c2)
    return pheromone_edges.get(key, 0.1)

def add_pheromone(r1, c1, r2, c2, amount):
    key = get_edge_key(r1, c1, r2, c2)
    pheromone_edges[key] = pheromone_edges.get(key, 0.1) + amount

# exits list
exits = [(r, c) for r in range(ROWS) for c in range(COLS) if b[r][c] == 2]

# ----- SUCCESS CACHE FUNCTIONS -----
def update_success_cache(path):
    """Update the success cache with a successful path."""
    global cached_paths
    
    if len(path) < 2:
        return
    
    path_length = len(path)
    
    # Update cache for each cell in the path
    # Each cell remembers which direction led to success and how far
    for i in range(len(path) - 1):
        current = path[i]
        next_cell = path[i + 1]
        remaining_length = path_length - i
        
        # Only update if this is a better (shorter) path from this cell
        if current not in success_cache or success_cache[current][1] > remaining_length:
            success_cache[current] = [next_cell, remaining_length, 1]
        elif success_cache[current][0] == next_cell:
            # Same direction, increment usage count
            success_cache[current][2] += 1
    
    # Store complete path for visualization
    cached_paths.append((path_length, path.copy()))
    # Keep only the best paths
    cached_paths.sort(key=lambda x: x[0])
    cached_paths = cached_paths[:MAX_CACHED_PATHS]

def get_cache_weight(from_row, from_col, to_row, to_col):
    """Get weight bonus from success cache."""
    key = (from_row, from_col)
    if key in success_cache:
        cached_next, path_len, times_used = success_cache[key]
        if cached_next == (to_row, to_col):
            # This is a proven successful direction!
            # Weight increases with usage and decreases with path length
            confidence = min(times_used / 3.0, 2.0)  # Cap confidence bonus
            return (1.0 + confidence) * (50.0 / path_len)  # Shorter paths get higher weight
    return 0.0

# ----- HELPERS -----
def tile_to_pixels(row, col):
    x = col * TILE + TILE / 2
    y = row * TILE + TILE / 2
    return x, y

def manhattan_to_nearest_exit(row, col):
    if not exits:
        return 1.0
    dmin = min(abs(row - er) + abs(col - ec) for er, ec in exits)
    return 1.0 / (dmin + 1.0)

def get_valid_moves(row, col):
    moves = []
    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nr = row + dr
        nc = col + dc
        if 0 <= nr < ROWS and 0 <= nc < COLS and b[nr][nc] != 1:
            moves.append((nr, nc))
    return moves

def choose_next_cell(row, col, exploration_rate=0.1):
    """Choose next cell using ACO + Success Cache."""
    neighbors = get_valid_moves(row, col)
    if not neighbors:
        return row, col
    
    # Small chance of pure exploration (helps find new paths)
    if random.random() < exploration_rate:
        return random.choice(neighbors)
    
    weights = []
    cache_boost_applied = False
    
    for nr, nc in neighbors:
        # Standard ACO components
        tau = get_pheromone(row, col, nr, nc)  # Pheromone
        eta = manhattan_to_nearest_exit(nr, nc)  # Heuristic
        
        # NEW: Success cache component
        cache_weight = get_cache_weight(row, col, nr, nc)
        
        # Combined weight formula
        base_weight = (tau ** ALPHA) * (eta ** BETA)
        
        if cache_weight > 0:
            # Boost weight significantly for cached successful directions
            w = base_weight + (cache_weight ** GAMMA)
            cache_boost_applied = True
        else:
            w = base_weight
        
        weights.append(w)
    
    total = sum(weights)
    if total <= 0:
        return random.choice(neighbors)
    
    # Roulette wheel selection
    r = random.random() * total
    acc = 0.0
    for (nr, nc), w in zip(neighbors, weights):
        acc += w
        if r <= acc:
            return nr, nc
    
    return neighbors[-1]

def evaporate_pheromones():
    keys_to_remove = []
    for key in pheromone_edges:
        pheromone_edges[key] *= (1.0 - RHO)
        if pheromone_edges[key] < 0.01:
            keys_to_remove.append(key)
    for key in keys_to_remove:
        del pheromone_edges[key]

def deposit_pheromones(path):
    if len(path) < 2:
        return
    L = len(path)
    delta = Q / float(L)
    for i in range(len(path) - 1):
        r1, c1 = path[i]
        r2, c2 = path[i + 1]
        add_pheromone(r1, c1, r2, c2, delta)

def draw_brick_wall(surface, x, y, tile_size):
    pygame.draw.rect(surface, MORTAR, (x, y, tile_size, tile_size))
    
    brick_h = tile_size // 3
    brick_w = tile_size // 2
    gap = 1
    
    for row in range(3):
        offset = (brick_w // 2) if row % 2 == 1 else 0
        by = y + row * brick_h
        
        for col in range(-1, 3):
            bx = x + col * brick_w + offset
            color = WALL_DARK if (row + col) % 2 == 0 else WALL_LIGHT
            
            rect_x = max(bx + gap, x)
            rect_y = by + gap
            rect_w = brick_w - gap * 2
            rect_h = brick_h - gap * 2
            
            if rect_x < x + tile_size and rect_x + rect_w > x:
                draw_w = min(rect_w, x + tile_size - rect_x)
                if rect_x < x:
                    draw_w -= (x - rect_x)
                    rect_x = x
                pygame.draw.rect(surface, color, (rect_x, rect_y, draw_w, rect_h))

def draw_door(surface, x, y, tile_size):
    pygame.draw.rect(surface, EMPTY, (x, y, tile_size, tile_size))
    
    door_x = x + 4
    door_y = y + 2
    door_w = tile_size - 8
    door_h = tile_size - 4
    
    pygame.draw.rect(surface, DOOR_WOOD, (door_x, door_y, door_w, door_h))
    
    panel_margin = 3
    panel_h = (door_h - 3 * panel_margin) // 2
    panel_w = door_w - 2 * panel_margin
    
    pygame.draw.rect(surface, DOOR_DARK, 
                     (door_x + panel_margin, door_y + panel_margin, 
                      panel_w, panel_h))
    pygame.draw.rect(surface, DOOR_DARK,
                     (door_x + panel_margin, door_y + 2 * panel_margin + panel_h,
                      panel_w, panel_h))
    
    handle_x = door_x + door_w - 6
    handle_y = door_y + door_h // 2
    pygame.draw.circle(surface, DOOR_HANDLE, (handle_x, handle_y), 2)
    pygame.draw.rect(surface, (60, 40, 20), (door_x, door_y, door_w, door_h), 1)

def draw_pheromone_trails(surface):
    """Draw thin lines for pheromone trails."""
    max_pheromone = 5.0
    
    for key, level in pheromone_edges.items():
        r1, c1, r2, c2 = key
        intensity = min(level / max_pheromone, 1.0)
        
        if intensity > 0.05:
            x1, y1 = tile_to_pixels(r1, c1)
            x2, y2 = tile_to_pixels(r2, c2)
            
            green = int(100 + 155 * intensity)
            width = max(1, int(intensity * 3))
            
            color = (0, green, 100)
            pygame.draw.line(surface, color, (int(x1), int(y1)), (int(x2), int(y2)), width)

def draw_cached_paths(surface):
    """Draw the best cached paths in gold."""
    if not cached_paths:
        return
    
    # Draw best path more prominently
    for idx, (path_len, path) in enumerate(cached_paths):
        if len(path) < 2:
            continue
        
        # Best path is brighter
        alpha = 255 if idx == 0 else 150
        width = 4 if idx == 0 else 2
        
        color = (255, 200, 0) if idx == 0 else (200, 150, 0)
        
        for i in range(len(path) - 1):
            r1, c1 = path[i]
            r2, c2 = path[i + 1]
            x1, y1 = tile_to_pixels(r1, c1)
            x2, y2 = tile_to_pixels(r2, c2)
            pygame.draw.line(surface, color, (int(x1), int(y1)), (int(x2), int(y2)), width)

def draw_cache_indicators(surface):
    """Draw small arrows showing cached directions."""
    for (row, col), (next_cell, path_len, times_used) in success_cache.items():
        nr, nc = next_cell
        
        # Only show well-established cache entries
        if times_used < 2:
            continue
        
        x1, y1 = tile_to_pixels(row, col)
        x2, y2 = tile_to_pixels(nr, nc)
        
        # Draw small indicator dot
        mid_x = (x1 + x2) / 2
        mid_y = (y1 + y2) / 2
        
        intensity = min(times_used / 5.0, 1.0)
        color = (int(255 * intensity), int(200 * intensity), 0)
        radius = 2 + int(intensity * 2)
        
        pygame.draw.circle(surface, color, (int(mid_x), int(mid_y)), radius)

def draw_stickman(surface, cx, cy, size, direction, color):
    """Draw a stickman at center position."""
    head_r = size // 8
    body_len = size // 4
    leg_len = size // 5
    arm_len = size // 5
    line_width = 2
    
    angle = math.atan2(direction[1], direction[0]) - math.pi / 2
    
    def rotate_point(px, py, angle):
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        return px * cos_a - py * sin_a, px * sin_a + py * cos_a
    
    head_offset = rotate_point(0, -body_len // 2 - head_r, angle)
    head_x = int(cx + head_offset[0])
    head_y = int(cy + head_offset[1])
    
    neck_offset = rotate_point(0, -body_len // 2 + 2, angle)
    neck_x = int(cx + neck_offset[0])
    neck_y = int(cy + neck_offset[1])
    
    hip_offset = rotate_point(0, body_len // 2, angle)
    hip_x = int(cx + hip_offset[0])
    hip_y = int(cy + hip_offset[1])
    
    shoulder_offset = rotate_point(0, -body_len // 4, angle)
    shoulder_x = int(cx + shoulder_offset[0])
    shoulder_y = int(cy + shoulder_offset[1])
    
    walk_phase = pygame.time.get_ticks() / 150.0 + hash(color) % 100
    leg_swing = math.sin(walk_phase) * 0.4
    arm_swing = -math.sin(walk_phase) * 0.3
    
    left_leg_angle = angle + math.pi / 6 + leg_swing
    left_foot = (hip_x + int(leg_len * math.sin(left_leg_angle)),
                 hip_y + int(leg_len * math.cos(left_leg_angle)))
    
    right_leg_angle = angle - math.pi / 6 - leg_swing
    right_foot = (hip_x + int(leg_len * math.sin(right_leg_angle)),
                  hip_y + int(leg_len * math.cos(right_leg_angle)))
    
    left_arm_angle = angle + math.pi / 4 + arm_swing
    left_hand = (shoulder_x + int(arm_len * math.sin(left_arm_angle)),
                 shoulder_y + int(arm_len * math.cos(left_arm_angle)))
    
    right_arm_angle = angle - math.pi / 4 - arm_swing
    right_hand = (shoulder_x + int(arm_len * math.sin(right_arm_angle)),
                  shoulder_y + int(arm_len * math.cos(right_arm_angle)))
    
    pygame.draw.circle(surface, color, (head_x, head_y), head_r, line_width)
    pygame.draw.line(surface, color, (neck_x, neck_y), (hip_x, hip_y), line_width)
    pygame.draw.line(surface, color, (hip_x, hip_y), left_foot, line_width)
    pygame.draw.line(surface, color, (hip_x, hip_y), right_foot, line_width)
    pygame.draw.line(surface, color, (shoulder_x, shoulder_y), left_hand, line_width)
    pygame.draw.line(surface, color, (shoulder_x, shoulder_y), right_hand, line_width)

# ----- ANT CLASS -----
class Ant:
    def __init__(self, ant_id, color):
        self.id = ant_id
        self.color = color
        self.start_row = 1 + ant_id % 3
        self.start_col = 1 + ant_id // 3
        self.row = self.start_row
        self.col = self.start_col
        self.x, self.y = tile_to_pixels(self.row, self.col)
        self.target_x = self.x
        self.target_y = self.y
        self.moving = False
        self.direction = (0, 1)
        self.path = [(self.row, self.col)]
        self.trips = 0
        self.best_path = float('inf')
        
        # Exploration rate decreases as ant gains experience
        self.exploration_rate = 0.15
    
    def update(self, dt):
        if not self.moving:
            if b[self.row][self.col] == 2:
                # Reached exit - SUCCESS!
                path_len = len(self.path)
                if path_len < self.best_path:
                    self.best_path = path_len
                self.trips += 1
                
                # Deposit pheromones
                deposit_pheromones(self.path)
                
                # UPDATE SUCCESS CACHE with this successful path
                update_success_cache(self.path)
                
                # Reduce exploration rate after success (exploit more)
                self.exploration_rate = max(0.02, self.exploration_rate * 0.9)
                
                # Reset to start
                self.row = self.start_row
                self.col = self.start_col
                self.x, self.y = tile_to_pixels(self.row, self.col)
                self.path = [(self.row, self.col)]
            else:
                # Choose next cell using ACO + Cache
                nr, nc = choose_next_cell(self.row, self.col, self.exploration_rate)
                if (nr, nc) != (self.row, self.col):
                    self.direction = (nc - self.col, nr - self.row)
                    self.target_x, self.target_y = tile_to_pixels(nr, nc)
                    self.path.append((nr, nc))
                    self.row, self.col = nr, nc
                    self.moving = True
        
        if self.moving:
            dx = self.target_x - self.x
            dy = self.target_y - self.y
            dist = math.hypot(dx, dy)
            
            if dist < 1:
                self.x, self.y = self.target_x, self.target_y
                self.moving = False
            else:
                speed = 180.0  # Slightly faster
                nx = dx / dist
                ny = dy / dist
                step = speed * dt
                if step >= dist:
                    self.x, self.y = self.target_x, self.target_y
                    self.moving = False
                else:
                    self.x += nx * step
                    self.y += ny * step
    
    def draw(self, surface):
        draw_stickman(surface, int(self.x), int(self.y), TILE, self.direction, self.color)

# Create ants
ants = [Ant(i, STICKMAN_COLORS[i % len(STICKMAN_COLORS)]) for i in range(NUM_ANTS)]

# ----- Pygame Setup -----
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT + 70))
pygame.display.set_caption("DWIGHT — Disaster Evacuation ACO")
font = pygame.font.Font(None, 22)
font_small = pygame.font.Font(None, 18)

clock = pygame.time.Clock()
running = True
frame_count = 0
show_cache = True  # Toggle with 'C' key

while running:
    dt = clock.tick(60) / 1000.0
    frame_count += 1

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_c:
                show_cache = not show_cache
            elif event.key == pygame.K_r:
                # Reset simulation
                pheromone_edges.clear()
                success_cache.clear()
                cached_paths.clear()
                for ant in ants:
                    ant.row = ant.start_row
                    ant.col = ant.start_col
                    ant.x, ant.y = tile_to_pixels(ant.row, ant.col)
                    ant.path = [(ant.row, ant.col)]
                    ant.trips = 0
                    ant.best_path = float('inf')
                    ant.exploration_rate = 0.15

    # Evaporate pheromones (but cache persists!)
    if frame_count % 5 == 0:
        evaporate_pheromones()

    # Update all ants
    for ant in ants:
        ant.update(dt)

    # ----- DRAW -----
    screen.fill(BG)

    # Draw grid
    for row in range(ROWS):
        for col in range(COLS):
            x = col * TILE
            y = row * TILE

            cell = b[row][col]
            if cell == 1:
                draw_brick_wall(screen, x, y, TILE)
            elif cell == 0:
                pygame.draw.rect(screen, EMPTY, (x, y, TILE, TILE))
            elif cell == 2:
                draw_door(screen, x, y, TILE)

    # Draw pheromone trails (green, fades)
    draw_pheromone_trails(screen)
    
    # Draw cached successful paths (gold, persistent)
    if show_cache:
        draw_cached_paths(screen)
        draw_cache_indicators(screen)

    # Draw all stickmen
    for ant in ants:
        ant.draw(screen)

    # Draw stats
    stats_y = HEIGHT + 5
    total_trips = sum(ant.trips for ant in ants)
    best_overall = min((ant.best_path for ant in ants if ant.best_path != float('inf')), default=float('inf'))
    cache_size = len(success_cache)
    
    trips_text = font.render(f"Trips: {total_trips}", True, (200, 200, 200))
    best_text = font.render(f"Best: {best_overall if best_overall != float('inf') else '-'}", True, (200, 200, 200))
    cache_text = font.render(f"Cache: {cache_size} cells", True, CACHED_PATH_COLOR)
    trails_text = font.render(f"Trails: {len(pheromone_edges)}", True, (0, 200, 100))
    
    screen.blit(trips_text, (10, stats_y))
    screen.blit(best_text, (100, stats_y))
    screen.blit(cache_text, (200, stats_y))
    screen.blit(trails_text, (340, stats_y))
    
    # Draw ant trip counts
    stats_y2 = HEIGHT + 28
    for i, ant in enumerate(ants):
        color_rect = pygame.Rect(10 + i * 110, stats_y2, 12, 12)
        pygame.draw.rect(screen, ant.color, color_rect)
        ant_stat = font.render(f": {ant.trips}", True, (180, 180, 180))
        screen.blit(ant_stat, (25 + i * 110, stats_y2))

    # Instructions
    stats_y3 = HEIGHT + 50
    instructions = font_small.render("Press C: toggle cache view | R: reset simulation | Gold = cached paths, Green = pheromones", True, (120, 120, 120))
    screen.blit(instructions, (10, stats_y3))

    pygame.display.flip()

pygame.quit()
