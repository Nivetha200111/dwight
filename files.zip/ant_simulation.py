import pygame
import random
import math

# ----- GRID -----
b = [
    [1,1,1,1,1,1,1,1],
    [1,0,0,0,0,0,0,1],
    [1,0,0,0,2,0,0,1],
    [1,0,0,0,0,0,0,1],
    [1,0,0,0,0,0,0,1],
    [1,0,2,0,0,0,0,1],
    [1,0,0,0,0,0,0,1],
    [1,1,1,1,1,1,1,1],
]

ROWS = len(b)
COLS = len(b[0])
TILE = 50

WIDTH = COLS * TILE
HEIGHT = ROWS * TILE

# Colors
WALL_DARK = (101, 67, 33)
WALL_LIGHT = (139, 90, 43)
MORTAR = (169, 169, 169)
EMPTY = (220, 220, 220)
DOOR_WOOD = (139, 90, 43)
DOOR_DARK = (101, 67, 33)
DOOR_HANDLE = (255, 215, 0)
STICKMAN = (30, 30, 30)
BG = (20, 20, 20)

# ----- HELPERS -----
def tile_to_pixels(row, col):
    """Return center pixel coordinates for a tile."""
    x = col * TILE + TILE / 2
    y = row * TILE + TILE / 2
    return x, y

def get_valid_moves(row, col):
    """Return list of (new_row, new_col) the ant can move to."""
    moves = []
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # up, down, left, right
    for dr, dc in directions:
        nr = row + dr
        nc = col + dc
        # inside grid and not a wall
        if 0 <= nr < ROWS and 0 <= nc < COLS and b[nr][nc] != 1:
            moves.append((nr, nc))
    return moves

def draw_brick_wall(surface, x, y, tile_size):
    """Draw a brick wall pattern."""
    # Fill with mortar color
    pygame.draw.rect(surface, MORTAR, (x, y, tile_size, tile_size))
    
    brick_h = tile_size // 4
    brick_w = tile_size // 2
    gap = 2
    
    for row in range(4):
        offset = (brick_w // 2) if row % 2 == 1 else 0
        by = y + row * brick_h
        
        for col in range(-1, 3):
            bx = x + col * brick_w + offset
            
            # Alternate brick colors
            color = WALL_DARK if (row + col) % 2 == 0 else WALL_LIGHT
            
            # Clip to tile bounds
            rect_x = max(bx + gap, x)
            rect_y = by + gap
            rect_w = brick_w - gap * 2
            rect_h = brick_h - gap * 2
            
            # Only draw if within tile
            if rect_x < x + tile_size and rect_x + rect_w > x:
                draw_w = min(rect_w, x + tile_size - rect_x)
                if rect_x < x:
                    draw_w -= (x - rect_x)
                    rect_x = x
                pygame.draw.rect(surface, color, (rect_x, rect_y, draw_w, rect_h))

def draw_door(surface, x, y, tile_size):
    """Draw a door."""
    # Door frame
    frame_width = 4
    pygame.draw.rect(surface, EMPTY, (x, y, tile_size, tile_size))
    
    # Door itself
    door_x = x + 6
    door_y = y + 4
    door_w = tile_size - 12
    door_h = tile_size - 6
    
    # Door base
    pygame.draw.rect(surface, DOOR_WOOD, (door_x, door_y, door_w, door_h))
    
    # Door panels
    panel_margin = 4
    panel_h = (door_h - 3 * panel_margin) // 2
    panel_w = door_w - 2 * panel_margin
    
    # Top panel
    pygame.draw.rect(surface, DOOR_DARK, 
                     (door_x + panel_margin, door_y + panel_margin, 
                      panel_w, panel_h))
    # Bottom panel
    pygame.draw.rect(surface, DOOR_DARK,
                     (door_x + panel_margin, door_y + 2 * panel_margin + panel_h,
                      panel_w, panel_h))
    
    # Door handle
    handle_x = door_x + door_w - 10
    handle_y = door_y + door_h // 2
    pygame.draw.circle(surface, DOOR_HANDLE, (handle_x, handle_y), 4)
    
    # Door frame border
    pygame.draw.rect(surface, (60, 40, 20), (door_x, door_y, door_w, door_h), 2)

def draw_stickman(surface, cx, cy, size, direction=(0, 1)):
    """Draw a stickman at center position (cx, cy)."""
    # Scale based on tile size
    head_r = size // 6
    body_len = size // 3
    leg_len = size // 4
    arm_len = size // 4
    line_width = 3
    
    # Calculate rotation angle based on direction
    angle = math.atan2(direction[1], direction[0]) - math.pi / 2
    
    def rotate_point(px, py, angle):
        """Rotate point around origin."""
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        return px * cos_a - py * sin_a, px * sin_a + py * cos_a
    
    # Head position (top of stickman)
    head_offset = rotate_point(0, -body_len // 2 - head_r, angle)
    head_x = int(cx + head_offset[0])
    head_y = int(cy + head_offset[1])
    
    # Neck (bottom of head)
    neck_offset = rotate_point(0, -body_len // 2 + 2, angle)
    neck_x = int(cx + neck_offset[0])
    neck_y = int(cy + neck_offset[1])
    
    # Hip (bottom of body)
    hip_offset = rotate_point(0, body_len // 2, angle)
    hip_x = int(cx + hip_offset[0])
    hip_y = int(cy + hip_offset[1])
    
    # Shoulder position
    shoulder_offset = rotate_point(0, -body_len // 4, angle)
    shoulder_x = int(cx + shoulder_offset[0])
    shoulder_y = int(cy + shoulder_offset[1])
    
    # Animate legs and arms with a simple walk cycle
    walk_phase = pygame.time.get_ticks() / 150.0
    leg_swing = math.sin(walk_phase) * 0.4
    arm_swing = -math.sin(walk_phase) * 0.3
    
    # Left leg
    left_leg_angle = angle + math.pi / 6 + leg_swing
    left_foot = (hip_x + int(leg_len * math.sin(left_leg_angle)),
                 hip_y + int(leg_len * math.cos(left_leg_angle)))
    
    # Right leg
    right_leg_angle = angle - math.pi / 6 - leg_swing
    right_foot = (hip_x + int(leg_len * math.sin(right_leg_angle)),
                  hip_y + int(leg_len * math.cos(right_leg_angle)))
    
    # Left arm
    left_arm_angle = angle + math.pi / 4 + arm_swing
    left_hand = (shoulder_x + int(arm_len * math.sin(left_arm_angle)),
                 shoulder_y + int(arm_len * math.cos(left_arm_angle)))
    
    # Right arm
    right_arm_angle = angle - math.pi / 4 - arm_swing
    right_hand = (shoulder_x + int(arm_len * math.sin(right_arm_angle)),
                  shoulder_y + int(arm_len * math.cos(right_arm_angle)))
    
    # Draw stickman parts
    # Head
    pygame.draw.circle(surface, STICKMAN, (head_x, head_y), head_r, line_width)
    
    # Body
    pygame.draw.line(surface, STICKMAN, (neck_x, neck_y), (hip_x, hip_y), line_width)
    
    # Legs
    pygame.draw.line(surface, STICKMAN, (hip_x, hip_y), left_foot, line_width)
    pygame.draw.line(surface, STICKMAN, (hip_x, hip_y), right_foot, line_width)
    
    # Arms
    pygame.draw.line(surface, STICKMAN, (shoulder_x, shoulder_y), left_hand, line_width)
    pygame.draw.line(surface, STICKMAN, (shoulder_x, shoulder_y), right_hand, line_width)

# ----- ANT STATE (GRID + PIXELS) -----
ant_row = 1
ant_col = 1

# start at center of that tile in pixels
ant_x, ant_y = tile_to_pixels(ant_row, ant_col)

# movement animation state
target_row = ant_row
target_col = ant_col
target_x = ant_x
target_y = ant_y
moving = False

# Direction the stickman is facing
direction = (0, 1)  # Default facing down

SPEED = 120.0  # pixels per second

# ----- Pygame Setup -----
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DWIGHT — Stickman Escape")

clock = pygame.time.Clock()
running = True

while running:
    dt = clock.tick(60) / 1000.0  # seconds since last frame (60 FPS target)

    # ----- events -----
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # ----- UPDATE ANT -----
    # If ant is not currently moving and not on an exit, choose a new tile
    if not moving and b[ant_row][ant_col] != 2:
        valid_moves = get_valid_moves(ant_row, ant_col)
        if valid_moves:
            target_row, target_col = random.choice(valid_moves)
            target_x, target_y = tile_to_pixels(target_row, target_col)
            moving = True
            # Update direction based on movement
            direction = (target_col - ant_col, target_row - ant_row)

    # If in the middle of a move, interpolate towards target
    if moving:
        # direction vector
        dx = target_x - ant_x
        dy = target_y - ant_y
        dist = math.hypot(dx, dy)

        if dist < 1e-2:  # close enough
            ant_x, ant_y = target_x, target_y
            ant_row, ant_col = target_row, target_col
            moving = False
        else:
            # normalized direction
            nx = dx / dist
            ny = dy / dist
            # move based on speed and time delta
            step = SPEED * dt
            # don't overshoot target
            if step >= dist:
                ant_x, ant_y = target_x, target_y
                ant_row, ant_col = target_row, target_col
                moving = False
            else:
                ant_x += nx * step
                ant_y += ny * step

    # ----- DRAW -----
    screen.fill(BG)

    # Draw grid
    for row in range(ROWS):
        for col in range(COLS):
            x = col * TILE
            y = row * TILE

            cell = b[row][col]
            if cell == 1:
                draw_brick_wall(screen, x, y, TILE)
            elif cell == 0:
                pygame.draw.rect(screen, EMPTY, (x, y, TILE, TILE))
            elif cell == 2:
                draw_door(screen, x, y, TILE)

    # Draw stickman (centered at ant_x, ant_y)
    draw_stickman(screen, int(ant_x), int(ant_y), TILE, direction)

    pygame.display.flip()

pygame.quit()
