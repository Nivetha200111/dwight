import pygame
import random
import math

# ----- GRID (20x30) -----
b = []
ROWS = 20
COLS = 30

# Generate maze with walls around edges and some internal walls
for r in range(ROWS):
    row = []
    for c in range(COLS):
        if r == 0 or r == ROWS - 1 or c == 0 or c == COLS - 1:
            row.append(1)  # Border walls
        elif random.random() < 0.15:
            row.append(1)  # Random internal walls
        else:
            row.append(0)  # Empty
    b.append(row)

# Ensure start area is clear
for r in range(1, 4):
    for c in range(1, 4):
        b[r][c] = 0

# Add multiple exits
exit_positions = [
    (1, COLS - 2),
    (ROWS - 2, COLS - 2),
    (ROWS // 2, COLS - 2),
    (ROWS - 2, COLS // 2),
]
for er, ec in exit_positions:
    b[er][ec] = 2

TILE = 30
WIDTH = COLS * TILE
HEIGHT = ROWS * TILE

# Colors
WALL_DARK = (101, 67, 33)
WALL_LIGHT = (139, 90, 43)
MORTAR = (169, 169, 169)
EMPTY = (220, 220, 220)
DOOR_WOOD = (139, 90, 43)
DOOR_DARK = (101, 67, 33)
DOOR_HANDLE = (255, 215, 0)
BG = (20, 20, 20)

# Stickman colors for multiple ants
STICKMAN_COLORS = [
    (200, 50, 50),    # Red
    (50, 50, 200),    # Blue
    (50, 180, 50),    # Green
    (200, 150, 50),   # Orange
    (150, 50, 200),   # Purple
    (50, 180, 180),   # Cyan
    (200, 50, 150),   # Pink
    (100, 100, 100),  # Gray
]

NUM_ANTS = 8

# ----- ACO PARAMETERS -----
ALPHA = 1.0
BETA = 3.0
RHO = 0.02  # Slower evaporation for bigger grid
Q = 100.0

# Pheromone stored as edges between cells for thin trails
# pheromone_edges[(r1,c1,r2,c2)] = level
pheromone_edges = {}

def get_edge_key(r1, c1, r2, c2):
    """Get canonical key for edge between two cells."""
    if (r1, c1) < (r2, c2):
        return (r1, c1, r2, c2)
    return (r2, c2, r1, c1)

def get_pheromone(r1, c1, r2, c2):
    key = get_edge_key(r1, c1, r2, c2)
    return pheromone_edges.get(key, 0.1)

def add_pheromone(r1, c1, r2, c2, amount):
    key = get_edge_key(r1, c1, r2, c2)
    pheromone_edges[key] = pheromone_edges.get(key, 0.1) + amount

# exits list
exits = [(r, c) for r in range(ROWS) for c in range(COLS) if b[r][c] == 2]

# ----- HELPERS -----
def tile_to_pixels(row, col):
    x = col * TILE + TILE / 2
    y = row * TILE + TILE / 2
    return x, y

def manhattan_to_nearest_exit(row, col):
    if not exits:
        return 1.0
    dmin = min(abs(row - er) + abs(col - ec) for er, ec in exits)
    return 1.0 / (dmin + 1.0)

def get_valid_moves(row, col):
    moves = []
    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nr = row + dr
        nc = col + dc
        if 0 <= nr < ROWS and 0 <= nc < COLS and b[nr][nc] != 1:
            moves.append((nr, nc))
    return moves

def choose_next_cell(row, col):
    neighbors = get_valid_moves(row, col)
    if not neighbors:
        return row, col

    weights = []
    for nr, nc in neighbors:
        tau = get_pheromone(row, col, nr, nc)
        eta = manhattan_to_nearest_exit(nr, nc)
        w = (tau ** ALPHA) * (eta ** BETA)
        weights.append(w)

    total = sum(weights)
    if total <= 0:
        return random.choice(neighbors)

    r = random.random() * total
    acc = 0.0
    for (nr, nc), w in zip(neighbors, weights):
        acc += w
        if r <= acc:
            return nr, nc

    return neighbors[-1]

def evaporate_pheromones():
    keys_to_remove = []
    for key in pheromone_edges:
        pheromone_edges[key] *= (1.0 - RHO)
        if pheromone_edges[key] < 0.01:
            keys_to_remove.append(key)
    for key in keys_to_remove:
        del pheromone_edges[key]

def deposit_pheromones(path):
    if len(path) < 2:
        return
    L = len(path)
    delta = Q / float(L)
    for i in range(len(path) - 1):
        r1, c1 = path[i]
        r2, c2 = path[i + 1]
        add_pheromone(r1, c1, r2, c2, delta)

def draw_brick_wall(surface, x, y, tile_size):
    pygame.draw.rect(surface, MORTAR, (x, y, tile_size, tile_size))
    
    brick_h = tile_size // 3
    brick_w = tile_size // 2
    gap = 1
    
    for row in range(3):
        offset = (brick_w // 2) if row % 2 == 1 else 0
        by = y + row * brick_h
        
        for col in range(-1, 3):
            bx = x + col * brick_w + offset
            color = WALL_DARK if (row + col) % 2 == 0 else WALL_LIGHT
            
            rect_x = max(bx + gap, x)
            rect_y = by + gap
            rect_w = brick_w - gap * 2
            rect_h = brick_h - gap * 2
            
            if rect_x < x + tile_size and rect_x + rect_w > x:
                draw_w = min(rect_w, x + tile_size - rect_x)
                if rect_x < x:
                    draw_w -= (x - rect_x)
                    rect_x = x
                pygame.draw.rect(surface, color, (rect_x, rect_y, draw_w, rect_h))

def draw_door(surface, x, y, tile_size):
    pygame.draw.rect(surface, EMPTY, (x, y, tile_size, tile_size))
    
    door_x = x + 4
    door_y = y + 2
    door_w = tile_size - 8
    door_h = tile_size - 4
    
    pygame.draw.rect(surface, DOOR_WOOD, (door_x, door_y, door_w, door_h))
    
    panel_margin = 3
    panel_h = (door_h - 3 * panel_margin) // 2
    panel_w = door_w - 2 * panel_margin
    
    pygame.draw.rect(surface, DOOR_DARK, 
                     (door_x + panel_margin, door_y + panel_margin, 
                      panel_w, panel_h))
    pygame.draw.rect(surface, DOOR_DARK,
                     (door_x + panel_margin, door_y + 2 * panel_margin + panel_h,
                      panel_w, panel_h))
    
    handle_x = door_x + door_w - 6
    handle_y = door_y + door_h // 2
    pygame.draw.circle(surface, DOOR_HANDLE, (handle_x, handle_y), 2)
    pygame.draw.rect(surface, (60, 40, 20), (door_x, door_y, door_w, door_h), 1)

def draw_pheromone_trails(surface):
    """Draw thin lines for pheromone trails."""
    max_pheromone = 5.0
    
    for key, level in pheromone_edges.items():
        r1, c1, r2, c2 = key
        intensity = min(level / max_pheromone, 1.0)
        
        if intensity > 0.05:
            x1, y1 = tile_to_pixels(r1, c1)
            x2, y2 = tile_to_pixels(r2, c2)
            
            # Color intensity based on pheromone level
            green = int(100 + 155 * intensity)
            alpha = int(50 + 200 * intensity)
            width = max(1, int(intensity * 4))
            
            color = (0, green, 100)
            pygame.draw.line(surface, color, (int(x1), int(y1)), (int(x2), int(y2)), width)

def draw_stickman(surface, cx, cy, size, direction, color):
    """Draw a stickman at center position."""
    head_r = size // 8
    body_len = size // 4
    leg_len = size // 5
    arm_len = size // 5
    line_width = 2
    
    angle = math.atan2(direction[1], direction[0]) - math.pi / 2
    
    def rotate_point(px, py, angle):
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        return px * cos_a - py * sin_a, px * sin_a + py * cos_a
    
    head_offset = rotate_point(0, -body_len // 2 - head_r, angle)
    head_x = int(cx + head_offset[0])
    head_y = int(cy + head_offset[1])
    
    neck_offset = rotate_point(0, -body_len // 2 + 2, angle)
    neck_x = int(cx + neck_offset[0])
    neck_y = int(cy + neck_offset[1])
    
    hip_offset = rotate_point(0, body_len // 2, angle)
    hip_x = int(cx + hip_offset[0])
    hip_y = int(cy + hip_offset[1])
    
    shoulder_offset = rotate_point(0, -body_len // 4, angle)
    shoulder_x = int(cx + shoulder_offset[0])
    shoulder_y = int(cy + shoulder_offset[1])
    
    walk_phase = pygame.time.get_ticks() / 150.0 + hash(color) % 100
    leg_swing = math.sin(walk_phase) * 0.4
    arm_swing = -math.sin(walk_phase) * 0.3
    
    left_leg_angle = angle + math.pi / 6 + leg_swing
    left_foot = (hip_x + int(leg_len * math.sin(left_leg_angle)),
                 hip_y + int(leg_len * math.cos(left_leg_angle)))
    
    right_leg_angle = angle - math.pi / 6 - leg_swing
    right_foot = (hip_x + int(leg_len * math.sin(right_leg_angle)),
                  hip_y + int(leg_len * math.cos(right_leg_angle)))
    
    left_arm_angle = angle + math.pi / 4 + arm_swing
    left_hand = (shoulder_x + int(arm_len * math.sin(left_arm_angle)),
                 shoulder_y + int(arm_len * math.cos(left_arm_angle)))
    
    right_arm_angle = angle - math.pi / 4 - arm_swing
    right_hand = (shoulder_x + int(arm_len * math.sin(right_arm_angle)),
                  shoulder_y + int(arm_len * math.cos(right_arm_angle)))
    
    pygame.draw.circle(surface, color, (head_x, head_y), head_r, line_width)
    pygame.draw.line(surface, color, (neck_x, neck_y), (hip_x, hip_y), line_width)
    pygame.draw.line(surface, color, (hip_x, hip_y), left_foot, line_width)
    pygame.draw.line(surface, color, (hip_x, hip_y), right_foot, line_width)
    pygame.draw.line(surface, color, (shoulder_x, shoulder_y), left_hand, line_width)
    pygame.draw.line(surface, color, (shoulder_x, shoulder_y), right_hand, line_width)

# ----- ANT CLASS -----
class Ant:
    def __init__(self, ant_id, color):
        self.id = ant_id
        self.color = color
        self.row = 1 + ant_id % 3
        self.col = 1 + ant_id // 3
        self.x, self.y = tile_to_pixels(self.row, self.col)
        self.target_x = self.x
        self.target_y = self.y
        self.moving = False
        self.direction = (0, 1)
        self.path = [(self.row, self.col)]
        self.trips = 0
        self.best_path = float('inf')
    
    def update(self, dt):
        if not self.moving:
            if b[self.row][self.col] == 2:
                # Reached exit
                path_len = len(self.path)
                if path_len < self.best_path:
                    self.best_path = path_len
                self.trips += 1
                deposit_pheromones(self.path)
                
                # Reset to start
                self.row = 1 + self.id % 3
                self.col = 1 + self.id // 3
                self.x, self.y = tile_to_pixels(self.row, self.col)
                self.path = [(self.row, self.col)]
            else:
                nr, nc = choose_next_cell(self.row, self.col)
                if (nr, nc) != (self.row, self.col):
                    self.direction = (nc - self.col, nr - self.row)
                    self.target_x, self.target_y = tile_to_pixels(nr, nc)
                    self.path.append((nr, nc))
                    self.row, self.col = nr, nc
                    self.moving = True
        
        if self.moving:
            dx = self.target_x - self.x
            dy = self.target_y - self.y
            dist = math.hypot(dx, dy)
            
            if dist < 1:
                self.x, self.y = self.target_x, self.target_y
                self.moving = False
            else:
                speed = 150.0
                nx = dx / dist
                ny = dy / dist
                step = speed * dt
                if step >= dist:
                    self.x, self.y = self.target_x, self.target_y
                    self.moving = False
                else:
                    self.x += nx * step
                    self.y += ny * step
    
    def draw(self, surface):
        draw_stickman(surface, int(self.x), int(self.y), TILE, self.direction, self.color)

# Create ants
ants = [Ant(i, STICKMAN_COLORS[i % len(STICKMAN_COLORS)]) for i in range(NUM_ANTS)]

# ----- Pygame Setup -----
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT + 50))
pygame.display.set_caption("DWIGHT — ACO Colony")
font = pygame.font.Font(None, 22)

clock = pygame.time.Clock()
running = True
frame_count = 0

while running:
    dt = clock.tick(60) / 1000.0
    frame_count += 1

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Evaporate every few frames
    if frame_count % 5 == 0:
        evaporate_pheromones()

    # Update all ants
    for ant in ants:
        ant.update(dt)

    # ----- DRAW -----
    screen.fill(BG)

    # Draw grid
    for row in range(ROWS):
        for col in range(COLS):
            x = col * TILE
            y = row * TILE

            cell = b[row][col]
            if cell == 1:
                draw_brick_wall(screen, x, y, TILE)
            elif cell == 0:
                pygame.draw.rect(screen, EMPTY, (x, y, TILE, TILE))
            elif cell == 2:
                draw_door(screen, x, y, TILE)

    # Draw pheromone trails as thin lines
    draw_pheromone_trails(screen)

    # Draw all stickmen
    for ant in ants:
        ant.draw(screen)

    # Draw stats
    stats_y = HEIGHT + 5
    total_trips = sum(ant.trips for ant in ants)
    best_overall = min((ant.best_path for ant in ants if ant.best_path != float('inf')), default=float('inf'))
    
    trips_text = font.render(f"Total Trips: {total_trips}", True, (200, 200, 200))
    best_text = font.render(f"Best Path: {best_overall if best_overall != float('inf') else '-'}", True, (200, 200, 200))
    ants_text = font.render(f"Ants: {NUM_ANTS}", True, (200, 200, 200))
    trails_text = font.render(f"Active Trails: {len(pheromone_edges)}", True, (200, 200, 200))
    
    screen.blit(trips_text, (10, stats_y))
    screen.blit(best_text, (150, stats_y))
    screen.blit(ants_text, (300, stats_y))
    screen.blit(trails_text, (400, stats_y))
    
    # Draw ant trip counts
    stats_y2 = HEIGHT + 28
    for i, ant in enumerate(ants):
        color_rect = pygame.Rect(10 + i * 110, stats_y2, 12, 12)
        pygame.draw.rect(screen, ant.color, color_rect)
        ant_stat = font.render(f": {ant.trips}", True, (180, 180, 180))
        screen.blit(ant_stat, (25 + i * 110, stats_y2))

    pygame.display.flip()

pygame.quit()
